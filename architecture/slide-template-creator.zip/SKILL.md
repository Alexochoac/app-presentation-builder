---
name: slide-template-creator
description: Creates HTML slide templates for the App Presentation Builder. Use when the user says "create a slide", "new slide", "new template", or asks to generate a slide template. Guides the user through a short Q&A and outputs a ready-to-import HTML file.
---

# Slide Template Creator

When triggered, run the following flow — ask Step 1 questions, wait for answers, then execute Steps 2, 3, and 4 in order.

## Step 1 — Ask these questions in one message

```
I'll create a slide template for you. A few quick questions:

1. **Slide number** — What's the next slide number? (e.g. ls16, ls17)
2. **Slide name** — Short name for the slide (e.g. stats, team, timeline)
3. **Slide type** — Pick one: Cover · Content · Stats/Metrics · Visual/Gallery · Two-Column · CTA · Data/Chart
4. **Content blocks** — What goes on this slide? List the elements (e.g. "headline, 3 stat numbers, a supporting image, a short paragraph")
5. **Interactive elements** — Any tabs, carousels, image lightbox, editable list, capability table, CTA buttons, or tag chips?
6. **Live data?** — Will any values be fed via webhook? If yes, which ones?
7. **Slide mode** — Does this slide appear in the normal flow, or is it a hidden drill-down triggered by another slide?
```

## Step 2 — Output the visual preview

**You MUST output this step.** Generate a complete, standalone HTML page (full `<!DOCTYPE html>` document) as an `html` code block. This lets the user see the slide rendered directly in Claude before importing it into the app. Do not skip this step.

This preview page is NOT imported into the app — it is only for visual review.

The `<head>` must contain **two `<style>` blocks** in this order:
1. The **full verbatim contents of `app-base.css`** (included in this skill package). Copy every line — do not summarise.
2. The **full verbatim contents of `components.css`** (included in this skill package). Copy every line — do not summarise. This provides the CSS that standard components (tabs, carousel, list, table) inject at runtime in the real app.

The `<body>` must contain:
1. A `.slides-container` div wrapping two `.glow-orb` divs (class `a` and `b`) followed by the slide fragment.
2. The slide fragment's root element must include `active` in its class list so it renders visible, e.g. `class="slide content ls[NN]-[name] active"`.

A `<script>` block at the **very start of `<body>`** (before the slide HTML) must define all app globals. This version includes working tab and carousel interactions for the preview:

```js
window.Track = { slideId:function(el){return el?(el.closest('[data-slide]')||{}).dataset.slide||'preview':'preview';}, click:function(){}, tab:function(){}, carousel:function(){}, expand:function(){}, zoom:function(){}, event:function(){} };
window.Tabs = { init: function(root) {
  (root||document).querySelectorAll('.ls-tab').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var tabs = btn.closest('.ls-tabs'); if (!tabs) return;
      var panel = btn.getAttribute('data-panel');
      tabs.querySelectorAll('.ls-tab').forEach(function(t){t.classList.remove('active');});
      tabs.querySelectorAll('.ls-tab-panel').forEach(function(p){p.classList.remove('active');});
      btn.classList.add('active');
      var target = tabs.querySelector('.ls-tab-panel[data-panel="'+panel+'"]');
      if (target) target.classList.add('active');
    });
  });
}};
window.Carousel = { init: function(root) {
  (root||document).querySelectorAll('.ls-carousel').forEach(function(car) {
    var track = car.querySelector('.ls-carousel-track'); if (!track) return;
    var slides = track.querySelectorAll('.ls-carousel-slide');
    var total = slides.length; if (total < 2) return;
    var idx = 0;
    function go(n) { idx=(idx+n+total)%total; track.style.transform='translateX(-'+idx*100+'%)'; }
    ['prev','next'].forEach(function(dir) {
      var btn = document.createElement('button');
      btn.textContent = dir==='prev' ? '‹' : '›';
      btn.style.cssText = 'position:absolute;top:50%;transform:translateY(-50%);'+(dir==='prev'?'left:8px':'right:8px')+';z-index:10;background:rgba(0,0,0,.5);color:#fff;border:none;border-radius:50%;width:28px;height:28px;font-size:18px;cursor:pointer;';
      btn.onclick = function(e){e.stopPropagation();go(dir==='next'?1:-1);};
      car.appendChild(btn);
    });
  });
}};
window.Lightbox = { init:function(){} };
window.List     = { init:function(){} };
window.LSTable  = { init:function(){} };
window.PE = { initSlide: function(root) {
  Tabs.init(root); Carousel.init(root); Lightbox.init(root); List.init(root); LSTable.init(root);
}};
```

**Tabs and carousels are interactive in the preview.** Lightbox, list editing, and table editing are disabled — they work fully once imported into the app.

After this code block, write: **"👆 Preview only — do not save this file."**

## Step 3 — Output the importable fragment

**You MUST output this step.** Generate the clean HTML fragment (the `<div class="slide...">` block only — no `<html>`, `<head>`, or `<body>` tags) as an `html` code block. This is the file the user will import into the app.

The root slide class must NOT include `active` in this version.

See ANATOMY.md for the full spec. Key rules:

**Root element:**
```html
<div class="slide content ls[NN]-[name]"
     data-slide="ls[NN]-[name]"
     data-slide-mode="sequence|embedded">
```

**Text nodes:** every visible text element gets `data-edit="key"` (kebab-case), `data-lang-key="ls[NN]-[name].key"`, `contenteditable spellcheck="false"`, and dummy placeholder text only — no real content.

**Style rules:** all colors via CSS variables (`var(--accent)`, `var(--text)`, `var(--bg-card)`, `var(--border)`, `var(--text-muted)`). Never hardcode hex or rgb theme colors. Mobile-first CSS, desktop overrides in `@media(min-width:769px)`. Scoped to the slide's class. **Do NOT include CSS for standard component classes** — their styles are injected by the component scripts.

**Tracking rules:** use `Track.click(slideId, 'label')` for buttons/links, `Track.tab(slideId, 'Label')` for tabs, `Track.carousel(slideId, 'next'/'prev', 'caption')` for carousels, `Track.expand(slideId, 'Section')` for accordions. Get slideId via `var slideId = Track.slideId(slide);`. Never call `window.umami.track()` directly. Standard components handle their own tracking — only wire explicit `Track.*` calls for non-component interactions.

**Data feed** (only if user said yes): `<span data-feed="metric-key" data-feed-type="number">0</span>`

**Builder-only elements:** `<button data-builder-only="">+ Add Item</button>`

**Script block:** always end the IIFE with `setTimeout(function () { if (window.PE) PE.initSlide(slide); }, 0);`

---

### Standard Components — ALWAYS use these, never invent your own

#### Tabs — `ls-tabs`
Use for any tabbed content. Do NOT write custom tab-switching JS or tab CSS.
```html
<div class="ls-tabs" data-edit="tabs" data-track="[slide-id]:tabs"
     style="flex:1;min-height:0;width:100%;">
  <div class="ls-tab-list">
    <button class="ls-tab active" data-panel="0">Tab One</button>
    <button class="ls-tab" data-panel="1">Tab Two</button>
  </div>
  <div class="ls-tab-panels">
    <div class="ls-tab-panel active" data-panel="0">
      <!-- any content — carousels, text, stats -->
    </div>
    <div class="ls-tab-panel" data-panel="1">
      <!-- any content -->
    </div>
  </div>
</div>
```
Rules: one `data-edit="tabs"` on the wrapper (whole block saved as a blob). Do NOT put `data-edit` on individual tab buttons. `data-panel` values must match between button and panel.

#### Carousel — `ls-carousel`
Use for any image gallery. Do NOT write custom carousel JS or CSS.
```html
<!-- Standalone (has its own data-edit) -->
<div class="ls-carousel" data-edit="carousel" data-counter=""
     style="flex:1;min-height:0;width:100%;">
  <div class="ls-carousel-track">
    <div class="ls-carousel-slide">
      <img src="" alt="First image caption" data-zoom>
    </div>
    <div class="ls-carousel-slide">
      <img src="" alt="Second image caption" data-zoom>
    </div>
  </div>
</div>

<!-- Inside a tab panel (no data-edit — saved as part of ls-tabs blob) -->
<div class="ls-tab-panel active" data-panel="0">
  <div class="ls-carousel" data-counter="" style="flex:1;min-height:0;width:100%;">
    <div class="ls-carousel-track">
      <div class="ls-carousel-slide">
        <img src="" alt="Image caption" data-zoom>
      </div>
    </div>
  </div>
</div>
```
Optional attributes: `data-autoplay="4000"` (ms), `data-zoom-group=""` (gallery lightbox), `data-no-caption` (suppress caption). Always add `data-zoom` to images.

#### Lightbox — `data-zoom`
Add `data-zoom` to any `<img>` for full-screen zoom on click. No extra JS needed.
```html
<img src="/slides/uploads/example.jpg" alt="Caption" data-zoom>

<!-- Grouped gallery -->
<div data-zoom-group>
  <img src="a.jpg" alt="First" data-zoom>
  <img src="b.jpg" alt="Second" data-zoom>
</div>
```

#### Editable List — `data-ls-list`
Use for any bullet/feature list that should be reorderable in the builder.
```html
<ul data-ls-list data-edit="feature-list">
  <li>First feature</li>
  <li>Second feature</li>
</ul>
<div data-ls-restore></div>  <!-- optional: restore hidden items -->
```

#### Capability Matrix Table — `data-ls-table`
Use for feature comparison tables with dot indicators.
```html
<div class="[slide-id]-table-wrap">
  <table data-ls-table data-edit="capability-table">
    <colgroup><col style="width:180px"><col><col></colgroup>
    <thead>
      <tr>
        <th></th>
        <th class="ls-th-col"><span class="ls-col-label">Our Product</span></th>
        <th class="ls-th-col ls-dot-red"><span class="ls-col-label">Competitor</span></th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Feature One</td>
        <td><span class="ls-dot ls-dot-on">◆</span></td>
        <td><span class="ls-dot ls-dot-off">◇</span></td>
      </tr>
    </tbody>
  </table>
  <div data-ls-col-restore></div>
  <div data-ls-row-restore></div>
  <button data-ls-add-row data-builder-only="">+ Add row</button>
</div>
```
Dot classes: `ls-dot-on` (filled ◆), `ls-dot-off` (outline ◇). Add `ls-dot-red` or `ls-dot-blue` to `<th>` to colour that column's dots.

#### CTA Button — `.slide-btn`
Use for all call-to-action buttons and links. Tracking is auto-wired.
```html
<a class="slide-btn"
   href="#"
   data-edit="cta-label"
   data-lang-key="[slide-id].cta-label"
   contenteditable spellcheck="false">Contact Us</a>
```
Style `.slide-btn` in the slide's scoped `<style>` block as needed.

#### Tag Chips — `.slide-tag`
Use for clickable category or filter tags. Tracking is auto-wired.
```html
<div class="slide-tags">
  <span class="slide-tag active"
        data-edit="tag-1"
        data-lang-key="[slide-id].tag-1"
        contenteditable spellcheck="false">Enterprise</span>
  <span class="slide-tag"
        data-edit="tag-2"
        data-lang-key="[slide-id].tag-2"
        contenteditable spellcheck="false">Cloud</span>
</div>
```
Style `.slide-tags` and `.slide-tag` in the slide's scoped `<style>` block.

---

### Standard slide wrapper structure

```html
<div class="slide-logo-row">
  <img src="/slides/shared/LOGO SoftSolution grays.png" alt="Softsolution">
  <span class="slide-logo-sep"></span>
  <img src="/slides/shared/LOGO LiteSentry Greys.png" alt="LiteSentry" class="slide-logo-ls">
</div>
<div class="slide-layout">
  <header class="slide-head">
    <div class="section-label" data-edit="section-label" data-lang-key="[id].section-label" contenteditable spellcheck="false">Section Name</div>
    <h1 class="slide-title" data-edit="headline" data-lang-key="[id].headline" contenteditable spellcheck="false">Dummy Headline</h1>
    <div class="divider"></div>
  </header>
  <div class="slide-body">
    <!-- content here -->
  </div>
</div>
```

After this code block, write: **"Save this as: `slide-[NN]-[name].html` → drop it in `builder/features/slides/`"**

## Step 4 — Show the checklist

After Step 3, always show:

```
✅ Checklist
- [x] data-slide + data-slide-mode on root
- [x] Every text node has data-edit + data-lang-key + contenteditable
- [x] No hardcoded theme colors — CSS variables only
- [x] No component CSS in <style> (ls-tabs, ls-carousel, ls-dot, etc.)
- [x] Tabs use ls-tabs markup — no custom tab JS
- [x] Carousels use ls-carousel markup — no custom carousel JS
- [x] Images use data-zoom for lightbox
- [x] Lists use data-ls-list
- [x] Tables use data-ls-table
- [x] CTA buttons use .slide-btn
- [x] Tag chips use .slide-tag
- [x] Only non-component interactions wired in <script> IIFE
- [x] Scoped <style> block (layout only)
- [x] Scoped <script> IIFE ending with PE.initSlide()
- [x] Dummy content only — no real customer data
- [ ] data-feed slots (not needed / added for: ___)
- [x] data-builder-only on builder controls
```

Mark items accordingly based on what was generated. Omit checklist items for components that weren't used.
